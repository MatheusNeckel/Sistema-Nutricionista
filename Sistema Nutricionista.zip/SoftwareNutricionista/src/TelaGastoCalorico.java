import javax.swing.JOptionPane;

public class TelaGastoCalorico extends javax.swing.JFrame {

    public TelaGastoCalorico() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        GrupoSexo = new javax.swing.ButtonGroup();
        lblCalculodeGastoCalorico = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jrbHomem = new javax.swing.JRadioButton();
        jrbMulher = new javax.swing.JRadioButton();
        lblPeso = new javax.swing.JLabel();
        lblAltura = new javax.swing.JLabel();
        lblIdade = new javax.swing.JLabel();
        lblNiveldeAtividade = new javax.swing.JLabel();
        txtPeso = new javax.swing.JTextField();
        txtAltura = new javax.swing.JTextField();
        txtIdade = new javax.swing.JTextField();
        jcbNiveldeAtividade = new javax.swing.JComboBox<>();
        btnCalcular = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        lblGastoTotal = new javax.swing.JLabel();
        lblGastoBasal = new javax.swing.JLabel();
        lblRespGastoBasal = new javax.swing.JLabel();
        lblRespGastoTotal = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        lblCalculodeGastoCalorico.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblCalculodeGastoCalorico.setText("Cálculo de Gasto Calórico");

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        GrupoSexo.add(jrbHomem);
        jrbHomem.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jrbHomem.setText("Homem");

        GrupoSexo.add(jrbMulher);
        jrbMulher.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jrbMulher.setText("Mulher");

        lblPeso.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblPeso.setText("Peso (kg):");

        lblAltura.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblAltura.setText("Altura (cm):");

        lblIdade.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblIdade.setText("Idade:");

        lblNiveldeAtividade.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblNiveldeAtividade.setText("Nível de Atividade:");

        txtPeso.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtPeso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesoActionPerformed(evt);
            }
        });

        txtAltura.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtAltura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAlturaActionPerformed(evt);
            }
        });

        txtIdade.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtIdade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdadeActionPerformed(evt);
            }
        });

        jcbNiveldeAtividade.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jcbNiveldeAtividade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione uma opção:", "Sedentário", "Leve (exercício leve 1 a 3 dias/semana)", "Moderado (exercício moderado 3 a 5 dias/semana)", "Ativo (exercício pesado 5 a 6 dias/semana)", "Extremamente ativo (exercício pesado diário)" }));

        btnCalcular.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCalcular.setText("Calcular");
        btnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblPeso)
                            .addComponent(lblAltura)
                            .addComponent(lblIdade))
                        .addGap(66, 66, 66)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPeso, javax.swing.GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE)
                            .addComponent(txtAltura)
                            .addComponent(txtIdade, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jrbHomem, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jrbMulher, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnCalcular))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblNiveldeAtividade)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jcbNiveldeAtividade, 0, 1, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jrbMulher)
                    .addComponent(jrbHomem))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPeso)
                    .addComponent(txtPeso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAltura)
                    .addComponent(txtAltura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblIdade)
                    .addComponent(txtIdade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNiveldeAtividade)
                    .addComponent(jcbNiveldeAtividade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnCalcular)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        lblGastoTotal.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblGastoTotal.setText("Gasto Total:");

        lblGastoBasal.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblGastoBasal.setText("Gasto Basal:");

        lblRespGastoBasal.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        lblRespGastoTotal.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lblGastoBasal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblRespGastoBasal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lblGastoTotal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblRespGastoTotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblGastoBasal)
                    .addComponent(lblRespGastoBasal))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblGastoTotal)
                    .addComponent(lblRespGastoTotal))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(lblCalculodeGastoCalorico)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lblCalculodeGastoCalorico)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtPesoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesoActionPerformed

    private void txtIdadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdadeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdadeActionPerformed

    private void btnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularActionPerformed
        Double calBasal = null;
        Double calTotal = null;
        Double peso;
        Double altura;
        int idade;
        String gastBasal;
        String gastTotal;

        peso = Double.parseDouble(txtPeso.getText());

        idade = Integer.parseInt(txtIdade.getText());

        altura = Double.parseDouble(txtAltura.getText());

        if (jrbHomem.isSelected()) {
            calBasal = 66 + (13.8 * peso) + (5 * altura) - (6.8 * idade);
        }

        if (jrbMulher.isSelected()) {
            calBasal = 655 + (9.6 * peso) + (1.9 * altura) - (4.7 * idade);
        }

        gastBasal = String.valueOf(calBasal);

        lblRespGastoBasal.setText(gastBasal);
        
        
        if (jcbNiveldeAtividade.getSelectedItem().equals("Selecione uma opção:")) {
            JOptionPane.showMessageDialog(null, "Selecione um nível de atividade para continuar.");
        } else if (jcbNiveldeAtividade.getSelectedItem().equals("Sedentário")) {
            calTotal = calBasal * 1.2;
        } else if (jcbNiveldeAtividade.getSelectedItem().equals("Leve (exercício leve 1 a 3 dias/semana)")) {
            calTotal = calBasal * 1.375;
        } else if (jcbNiveldeAtividade.getSelectedItem().equals("Moderado (exercício moderado 3 a 5 dias/semana)")) {
            calTotal = calBasal * 1.55;
        } else if (jcbNiveldeAtividade.getSelectedItem().equals("Ativo (exercício pesado 5 a 6 dias/semana)")) {
            calTotal = calBasal * 1.725;
        } else if (jcbNiveldeAtividade.getSelectedItem().equals("Extremamente ativo (exercício pesado diário)")) {
            calTotal = calBasal * 1.9;
        }

        gastTotal = String.valueOf(calTotal);

        lblRespGastoTotal.setText(gastTotal);
        
        if (peso <= 0 || altura <= 0 || idade <= 0) {
            JOptionPane.showMessageDialog(null, "Número inválido. Informe um valor maior que 0.");
        }
        
        String strPeso = txtPeso.getText();
        String strAltura = txtAltura.getText();
        String strIdade = txtIdade.getText();
        
        if (strPeso.isEmpty() || strAltura.isEmpty() || strIdade.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Todos os campos devem ser preenchidos");
        } else {
            boolean numero = strPeso.matches("[0-9]{3}[,][0-9]{2}");
            boolean numero2 = strAltura.matches("[0-9]{1,2}[,][0-9]{2}");
            boolean numero3 = strIdade.matches("[0-9]{1,2}");
            if (numero == true & numero2 == true & numero3 == true) {
                JOptionPane.showMessageDialog(null, "Cálculo bem-sucedido.");
            } else {
                JOptionPane.showMessageDialog(null, "Formato inválido. Digite novamente.");
            }
        }
    }//GEN-LAST:event_btnCalcularActionPerformed

    private void txtAlturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAlturaActionPerformed
        // TODO add your handling code here: 
    }//GEN-LAST:event_txtAlturaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaGastoCalorico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaGastoCalorico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaGastoCalorico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaGastoCalorico.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaGastoCalorico().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup GrupoSexo;
    private javax.swing.JButton btnCalcular;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JComboBox<String> jcbNiveldeAtividade;
    private javax.swing.JRadioButton jrbHomem;
    private javax.swing.JRadioButton jrbMulher;
    private javax.swing.JLabel lblAltura;
    private javax.swing.JLabel lblCalculodeGastoCalorico;
    private javax.swing.JLabel lblGastoBasal;
    private javax.swing.JLabel lblGastoTotal;
    private javax.swing.JLabel lblIdade;
    private javax.swing.JLabel lblNiveldeAtividade;
    private javax.swing.JLabel lblPeso;
    private javax.swing.JLabel lblRespGastoBasal;
    private javax.swing.JLabel lblRespGastoTotal;
    private javax.swing.JTextField txtAltura;
    private javax.swing.JTextField txtIdade;
    private javax.swing.JTextField txtPeso;
    // End of variables declaration//GEN-END:variables
}
